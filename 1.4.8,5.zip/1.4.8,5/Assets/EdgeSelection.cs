using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EdgeSelection : MonoBehaviour {

    public static EdgeSelection Instance { set; get; } //Durch Instance von fast überall anwählbar 

    public GameObject SelectionPrefab;
    private List<GameObject> Selection; // neue Liste 
    private void Start() 
    {
        Instance = this;
        Selection = new List<GameObject> ();
    }
    private GameObject SelectedObject() 
    {
        GameObject go = Selection.Find(g => !g.activeSelf); //sucht ein inaktives Objekt (mit !g.activeSelf)

        if (go == null) // wenn wir kein objekt finden wird ein neues erstelt 
        {
            go = Instantiate(SelectionPrefab); 
            Selection.Add(go); 
        }
        return go;
    }

    public void SelectionOfAllowedMove(bool[,] moves)
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 16; j++)
            {
                if(moves[i,j])
                {
                    GameObject go = SelectedObject(); // wir haben ein inaktives objekt oder erstellen eins
                    go.SetActive(true); // setzt das objekt auf aktiv
                    go.transform.position = new Vector3(i+0.5f, 0, j+0.5f);
                }
            }
        }
    }
//Entfernt Hervorhebung
    public void HideSelection()
    {
        foreach (GameObject go in Selection)
            go.SetActive(false);
    }

}

