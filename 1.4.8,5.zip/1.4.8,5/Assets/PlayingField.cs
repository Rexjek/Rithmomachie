﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayingField : MonoBehaviour {

    private Stone[ , ] Feld;

    //Field / Feld
	
    public PlayingField()
    {

        Feld = new Stone[16, 8];
        for (int i = 0; i < 16; i++)
            for (int j = 0; j < 8; j++)
                Feld[i, j] = null; 



    }




    //Add Stone / Fügt Stein hinzu
    public void addStone(int x, int z, bool Farbe, int Wert, int F)
    {
        Stone Stein = new Stone(x, z, Farbe, Wert, F);
        Feld[x, z] = Stein;

    }
    
	void Start () {

        
		
	}
	//Updater / Aktualisiert
	void Update () {
		
	}
}
