﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stone : MonoBehaviour {
//Allgemeine Attribute für die Spielsteine / Spielobjekte
    private int MyForm;
    private bool Color;
    private int Value;
    private int x;
    private int z;
    public enum Forms
    {
        Round, //0
        Triangle, //1
        Square, //2
    }
//Erzeugt Stone mit übergebenen Parametern
    public Stone(int xIn, int zIn, bool ColorIn, int ValueIn, int F)
    {
        x = xIn;
        z = zIn;
        Color = ColorIn;
        Value = ValueIn;
        MyForm = F;
    }
    
	void Start () {
        
	}
	
	void Update () {
		
	}

    

    
}
