using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triangle : Player
{
    public override bool[,] PossibleMove()
    {
        bool[,] r = new bool[10, 18];
        Player c, c2, c3;

        c = null;
        c2 = null;
        c3 = null;
        Debug.Log(CurrentX + " " + CurrentY);

//Alle m�glichen Spielz�ge des Dreiecks werden �berpr�ft und auf dessen Anforderungen getestet.
        if (!isWhite)
        {

            //Vorw�rts3
            if (CurrentY != 2 && CurrentY != 1 && CurrentY != 0)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX , CurrentY -1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX , CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2  ? Game.Instance.Playerx[CurrentX , CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX, CurrentY - 3] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 1 && CurrentY != 0)
            {
                c =  CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 1 && CurrentY != 0)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX , CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

               
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1)
            {
                c = CurrentY > 0? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

            
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

              
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentX != 7 && CurrentX != 6 && CurrentY != 0)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentY != 0 && CurrentX != 7 && CurrentX != 6)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //3 hoch
            if ( CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX -1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX -2 , CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX -3 , CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                
                
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 3, CurrentY] = true;
                }
            }

            //3 runter
            if (CurrentX != 5 && CurrentX != 6 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 3, CurrentY] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 15)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX -1, CurrentY ] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX -2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX > 1? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }
            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //3 rechts
            if (CurrentY != 13 && CurrentY != 14 && CurrentY != 15)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX, CurrentY + 3] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15  && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 14 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

               
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }
            return r;

        }
        else
        {

            //Vorw�rts3
            if (CurrentY != 2 && CurrentY != 1 && CurrentY != 0)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX, CurrentY - 3] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 1 && CurrentY != 0)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 1 && CurrentY != 0)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 1 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentX != 7 && CurrentX != 6 && CurrentY != 0)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentY != 0 && CurrentX != 7 && CurrentX != 6)
            {
                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //3 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 3, CurrentY] = true;
                }
            }

            //3 runter
            if (CurrentX != 5 && CurrentX != 6 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 3, CurrentY] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 15)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 15 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }
            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //3 rechts
            if (CurrentY != 13 && CurrentY != 14 && CurrentY != 15)
            {
                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX, CurrentY + 3] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 15 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 14 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null)// alle drei Null, auf dem Ziel und Weg steht keiner (man kann nicht �ber andere Steine ziehen!)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            return r;
        }



    }

}
