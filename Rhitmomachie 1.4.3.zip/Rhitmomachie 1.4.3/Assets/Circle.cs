using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Circle : Player  {
    public override bool[,] PossibleMove()
    {
        bool[,] r = new bool[16, 16];
        Player c, c2;
        // Wei� Bewegung

        if (isWhite)
        {
            c = null ;
           //Diagonal Links
           if(CurrentY != 0 && CurrentY !=16 && CurrentX !=0 && CurrentX !=8 )
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 1] = true;
                }
                
            }
            //Diagonal Rechts
             if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
                {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 1] = true;
                }
            }
           

            // Mitte 2
            
            if (CurrentY != 0 && CurrentY != 16)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 2] = true;
                }
            }
        }
        else
        {
            c = null;
            //Diagonal Links
            if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
                {
                c = Game.Instance.Playerx[CurrentX -1, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX -1, CurrentY - 1] = true;
                }

                  }
            //Diagonal Rechts
             if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
                {
                c = Game.Instance.Playerx[CurrentX +1 , CurrentY -1];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 1] = true;
                }
                }
            // Mitte
             if  (CurrentY != 0 && CurrentY != 16 )
                {
                c = Game.Instance.Playerx[CurrentX, CurrentY -2 ];
                if (c == null)
                {
                    r[CurrentX, CurrentY -2 ] = true;
                }
                }
            
             
        }
        return r;
    }
    


}
