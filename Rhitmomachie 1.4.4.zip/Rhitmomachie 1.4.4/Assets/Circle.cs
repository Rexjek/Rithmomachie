using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Circle : Player  {

    bool[,] r = new bool[8, 16];
    Player c, c2;
    sbyte moveX = 0;
    sbyte moveY = 0;
    public override bool[,] PossibleMove()
    {

        c = null;
        c2 = null;
        // Wei� Bewegung
        moveX = 0;
        moveY = 0;
        if (isWhite)
        {
            c = null;
            if (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8) { moveX = -1; moveY = 1; CurrentRAndC(); }
            if (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8) { moveX = 1; moveY = 1; CurrentRAndC(); }
            if (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8) { moveX = 0; moveY = 2; CurrentRAndC(); }


        }
            //Diagonal Links
            /*if (CurrentY != 0 && CurrentY !=16 && CurrentX !=0 && CurrentX !=8 )
         {
             c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
             if (c == null)
             {
                 r[CurrentX - 1, CurrentY + 1] = true;
             }

         }
         //Diagonal Rechts
          if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
             {
             c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
             if (c == null)
             {
                 r[CurrentX + 1, CurrentY + 1] = true;
             }
         }


         // Mitte 2

         if (CurrentY != 0 && CurrentY != 16)
         {
             c = Game.Instance.Playerx[CurrentX, CurrentY + 2];
             if (c == null)
             {
                 r[CurrentX, CurrentY + 2] = true;
             }
         }
         // Hinten 2
         if (CurrentY != 0 && CurrentY != 16)
         {
             c = Game.Instance.Playerx[CurrentX, CurrentY - 2];
             if (c == null)
             {
                 r[CurrentX, CurrentY -2] = true;
             }
         }
         //Rechts 2
         if (CurrentY != 0 && CurrentY != 16)
         {
             c = Game.Instance.Playerx[CurrentX +2 , CurrentY ];
             if (c == null)
             {
                 r[CurrentX +2, CurrentY ] = true;
             }
         }
         // Links 2
         if (CurrentY != 0 && CurrentY != 16)
         {
             c = Game.Instance.Playerx[CurrentX -2, CurrentY ];
             if (c == null)
             {
                 r[CurrentX -2, CurrentY ] = true;
             }
         }
         //Diagonal Links
         if (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
         {
             c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 1];
             if (c == null)
             {
                 r[CurrentX - 1, CurrentY - 1] = true;
             }

         }


     }
     else
     {
         c = null;
         //Diagonal Links
         if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
             {
             c = Game.Instance.Playerx[CurrentX -1, CurrentY - 1];
             if (c == null)
             {
                 r[CurrentX -1, CurrentY - 1] = true;
             }

               }
         //Diagonal Rechts
          if  (CurrentY != 0 && CurrentY != 16 && CurrentX != 0 && CurrentX != 8)
             {
             c = Game.Instance.Playerx[CurrentX +1 , CurrentY -1];
             if (c == null)
             {
                 r[CurrentX + 1, CurrentY - 1] = true;
             }
             }
         // Mitte
          if  (CurrentY != 0 && CurrentY != 16 )
             {
             c = Game.Instance.Playerx[CurrentX, CurrentY -2 ];
             if (c == null)
             {
                 r[CurrentX, CurrentY -2 ] = true;
             }
             }

         if (CurrentY != 0 && CurrentY != 16)
         {
             c = Game.Instance.Playerx[CurrentX, CurrentY + 2];
             if (c == null)
             {
                 r[CurrentX, CurrentY + 2] = true;
             }
         }


    }*/
    return CurrentRAndC();
}

            private bool[,] CurrentRAndC()
            {
                c = Game.Instance.Playerx[CurrentX + moveX, CurrentY + moveY];
                if (c == null)
                {
                    r[CurrentX + moveX, CurrentY + moveY] = true;
                }
                return r;
            }



        }
    
