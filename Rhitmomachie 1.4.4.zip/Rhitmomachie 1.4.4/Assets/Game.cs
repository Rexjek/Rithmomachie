using UnityEngine;
using System.Collections.Generic;

public class Game : MonoBehaviour {
    //Spieler == Spielstein
    public static Game Instance { set; get; }
    private bool [,] allowedMoves { set; get; }

    public Player[,] Playerx { set; get; }
    private Player selectedPlayer;
    public List<GameObject> Test2 ;
    //Deaktivierung der Spielsteine durch X-/Y-Wert = -1
    private const float tileSize = 1.0f;
    private const float tileDiameter = 0.5f;

    private int selectionX = -1;
    private int selectionY = -1;

    public List<GameObject> tokens1;
    private List<GameObject> activeTokens;

    private Quaternion orientation = Quaternion.Euler(90, 0, 0);
    private Quaternion orientation2 = Quaternion.Euler(90, 180, 0);
    public bool isWhiteTurn = true;

    private PlayingField MeinFeld = new PlayingField();

    //Initialize Spawner
    private void Start()
    {
        Instance = this;
        SpawnAll();

    } 

    //Spawn-Methode
    private void SpawnAll()
    {
        activeTokens = new List<GameObject>();
        Playerx = new Player[8, 16];

        //SpawnToken(Object, x, y)

        //Weißes Team

        //Weiß, Kreis 1
        SpawnToken(0, 2, 3);
        SpawnToken(1, 3, 3);
        SpawnToken(2, 4, 3);
        SpawnToken(3, 5, 3);

        //Weiß, Kreis 2  
        SpawnToken(4, 2, 2);
        SpawnToken(5, 3, 2);
        SpawnToken(6, 4, 2);
        SpawnToken(7, 5, 2);

        //Weiß, Viereck 1
        SpawnToken(8, 0, 1);
        SpawnToken(9, 1, 1);
        SpawnToken(10, 6, 1);
        SpawnToken(11, 7, 1);

        //Weiß, Viereck 2
        SpawnToken(12, 0, 0);
        SpawnToken(13, 1, 0);
        SpawnToken(14, 6, 0);
        SpawnToken(15, 7, 0);

        //Weiß, Dreieck 1
        SpawnToken(16, 0, 2);
        SpawnToken(17, 1, 2);
        SpawnToken(18, 6, 2);
        SpawnToken(19, 7, 2);

        //Weiß, Dreieck 2
        SpawnToken(20, 2, 1);
        SpawnToken(21, 3, 1);
        SpawnToken(22, 4, 1);
        SpawnToken(23, 5, 1);

        //Schwarz, Kreis 1
        SpawnToken(24, 2, 12);
        SpawnToken(25, 3, 12);
        SpawnToken(26, 4, 12);
        SpawnToken(27, 5, 12);

        //Schwarz, Kreis 2
        SpawnToken(28, 2, 13);
        SpawnToken(29, 3, 13);
        SpawnToken(30, 4, 13);
        SpawnToken(31, 5, 13);

        //Schwarz, Viereck 1
        SpawnToken(32, 0, 15);
        SpawnToken(33, 1, 15);
        SpawnToken(34, 6, 15);
        SpawnToken(35, 7, 15);

        //Schwarz, Viereck 2
        SpawnToken(36, 0, 14);
        SpawnToken(37, 1, 14);
        SpawnToken(38, 6, 14);
        SpawnToken(39, 7, 14);

        //Schwarz, Dreieck 1
        SpawnToken2(40, 2, 14);
        SpawnToken2(41, 3, 14);
        SpawnToken2(42, 4, 14);
        SpawnToken2(43, 5, 14);

        //Schwarz, Dreieck 2
        SpawnToken2(45, 0, 13);
        SpawnToken2(46, 1, 13);
        SpawnToken2(47, 6, 13);
        SpawnToken2(48, 7, 13);


    }

    private Vector3 Middle(int x, int z)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (tileSize * x) + tileDiameter;
        origin.z += (tileSize * z) + tileDiameter;
        return origin;
    } //Spawnpoint-Funktion
    

    //Selection + Move
    public void mouseSelection()
    {
        if (Input.GetMouseButtonDown(0)) // Auswählen (0= linke maustaste)
        {
            if (selectionX >= 0 && selectionY >= 0)
            {
                if (selectedPlayer == null)
                {
                    //Wähle Spieler aus
                    SelectPlayer(selectionX, selectionY);

                }

                else
                {
                    //Bewege den Spieler
                    movePlayer(selectionX, selectionY);
                }

            }
        }
    }
    

    //Updater
    public void Update() {

        UpdateSelection();
        Board();
        mouseSelection();

        
    }

   

    //Checks if Stone is White or Black?
    private void SelectPlayer (int x, int y)
     {
        if (Playerx[x, y] == null)
            return;

        if (Playerx[x, y].isWhite != isWhiteTurn)
            return;
        allowedMoves = Playerx[x, y].PossibleMove() ;
        selectedPlayer = Playerx[x, y];
        EdgeSelection.Instance.SelectionOfAllowedMove(allowedMoves);
        
     }

    private void movePlayer(int x,int y)
    {
        if (allowedMoves[x,y])
        {
            Playerx[selectedPlayer.CurrentX, selectedPlayer.CurrentY] = null;
            selectedPlayer.transform.position = Middle(x, y);
            selectedPlayer.SetPosition(x, y);
            Playerx[x, y] = selectedPlayer;
            isWhiteTurn = !isWhiteTurn;  
        }

        EdgeSelection.Instance.HideSelection();
        selectedPlayer = null;
    }
    
    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("Playboard")))
        {
            
            selectionX = (int)hit.point.x;
            selectionY = (int)hit.point.z;
        }
        else
        {
            selectionX = -1;
            selectionY = -1;
        }
    }

    public void Board()
    {
        Vector3 lineWidth = Vector3.right * 8;
        Vector3 lineLength = Vector3.forward * 16;
        for (int i = 0; i <= 16; i++)
        {
            Vector3 start = Vector3.forward * i ; 
            Debug.DrawLine(start, start + lineWidth );
            for (int k = 0; k <= 8; k++)
            {
                start = Vector3.right  * k;
                Debug.DrawLine(start, start + lineLength);
            }
        }
        

      //SelectionForm (Cross)
      if(selectionX >= 0 && selectionY >= 0)
        {
            Debug.DrawLine(
                Vector3.forward * selectionY + Vector3.right * selectionX,
                Vector3.forward * (selectionY + 1) + Vector3.right * (selectionX + 1));

            Debug.DrawLine(
                 Vector3.forward *( selectionY + 1) + Vector3.right * selectionX,
                 Vector3.forward * selectionY  + Vector3.right * (selectionX + 1));

        }
    }

    //Spawnt Steine
    public void SpawnToken(int index,int x, int y)
    {
        GameObject go = Instantiate(tokens1[index], Middle(x,y) , orientation) as GameObject; //Macht Steine mit dem Index 
        go.transform.SetParent(transform);
        Playerx [x, y] = go.GetComponent<Player>() ;
        Playerx[x, y].SetPosition(x, y); 
        activeTokens.Add(go);
    }

    public void SpawnToken2(int index, int x, int y)
    {
        GameObject go = Instantiate(tokens1[index], Middle(x, y), orientation2) as GameObject; //Macht Steine mit dem Index 
        go.transform.SetParent(transform);
        Playerx[x, y] = go.GetComponent<Player>();
        Playerx[x, y].SetPosition(x, y);
        activeTokens.Add(go);
    }
}

