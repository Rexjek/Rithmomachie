using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Square : Player
{
    public override bool[,] PossibleMove()
    {

        bool[,] r = new bool[10, 18];
        Player c, c2, c3, c4;

        c = null;
        c2 = null;
        c3 = null;
        c4 = null;
        Debug.Log(CurrentX + " " + CurrentY);



        if (!isWhite)
        {
            
            //Vorw�rts4
            if (CurrentY != 0  && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 4];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }               
            }

            //1 runter 3 links
            if (CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3 )
            {
                
                c = Game.Instance.Playerx[CurrentX +1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX +1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 links
            if (CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            // 1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 )
            {
                c = Game.Instance.Playerx[CurrentX -1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX -1, CurrentY - 3] = true;
                }
            }

            // 1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX , CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX , CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX , CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 )
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 )
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }


            //4 rechts
            if (CurrentY != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12 )
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 4];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }

            

            //runter 4
            if (CurrentX != 6 && CurrentX != 7 && CurrentX != 5 && CurrentX != 4)
            {
                c = Game.Instance.Playerx[CurrentX + 4, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }

            //3 runter 1 links
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5 )
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY -1] = true;
                }
            }

            //3 runter 1 links
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX , CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5 )
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY +1];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY +1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            // Links 4
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 4, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            // 3 hoch 1 links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY -1];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY -1] = true;
                }
            }

            // 3 hoch 1 links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY -1];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }


            // 3 hoch 1 rechts 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // 3 hoch 1 rechts 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // 2 hoch 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 )
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // 2 hoch 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // 2 hoch 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 )
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            // 2 hoch 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY -1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY -2];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            // 2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7 )
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            // 2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            // 2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7 )
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            // 2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            return r;
        }
        else
        {


            //Vorw�rts4
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 4];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }
            }

            //1 runter 3 links
            if (CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 links
            if (CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            // 1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            // 1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }


            //4 rechts
            if (CurrentY != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 4];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }



            //runter 4
            if (CurrentX != 6 && CurrentX != 7 && CurrentX != 5 && CurrentX != 4)
            {
                c = Game.Instance.Playerx[CurrentX + 4, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }

            //3 runter 1 links
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //3 runter 1 links
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            // Links 4
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 4, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            // 3 hoch 1 links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }

            // 3 hoch 1 links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 1];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }


            // 3 hoch 1 rechts 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // 3 hoch 1 rechts 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 1];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // 2 hoch 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // 2 hoch 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // 2 hoch 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            // 2 hoch 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            // 2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            // 2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            // 2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c4 = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            // 2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c4 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            return r;
        }




    }
}