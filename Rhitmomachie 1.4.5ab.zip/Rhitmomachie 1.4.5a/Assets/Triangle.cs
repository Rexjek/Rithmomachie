using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triangle : Player
{
    public override bool[,] PossibleMove()
    {
        bool[,] r = new bool[10, 18];
        Player c, c2, c3;

        c = null;
        c2 = null;
        c3 = null;
        Debug.Log(CurrentX + " " + CurrentY);


        if (!isWhite)
        {

            //Vorw�rts3
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY - 2];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY - 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX, CurrentY - 3] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY ];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 2];
                c2 = Game.Instance.Playerx[CurrentX , CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX , CurrentY - 2];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX -1, CurrentY - 1];
                c3 = Game.Instance.Playerx[CurrentX , CurrentY - 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                c2 = Game.Instance.Playerx[CurrentX - 2, CurrentY ];
                c3 = Game.Instance.Playerx[CurrentX -1, CurrentY ];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentX != 6 && CurrentX != 7 && CurrentY != 0 && CurrentY != 1)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //3 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX - 2, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 3, CurrentY] = true;
                }
            }

            //3 runter
            if (CurrentX != 6 && CurrentX !=7)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 3, CurrentY] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX - 2, CurrentY ];
                c3 = Game.Instance.Playerx[CurrentX - 1, CurrentY ];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            } 

            //1 rechts 2 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX , CurrentY +1];
                c3 = Game.Instance.Playerx[CurrentX -1, CurrentY +1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX , CurrentY +1];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }
            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                c2 = Game.Instance.Playerx[CurrentX +1 , CurrentY ];
                c3 = Game.Instance.Playerx[CurrentX + 2, CurrentY ];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX -1, CurrentY + 1];
                c3 = Game.Instance.Playerx[CurrentX -1, CurrentY ];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                if (c == null && c2== null && c3 == null )
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //3 rechts
            if (CurrentY != 13 && CurrentY != 14 && CurrentY != 15)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                c2 = Game.Instance.Playerx[CurrentX, CurrentY + 2];
                c3 = Game.Instance.Playerx[CurrentX, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX, CurrentY + 3] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 6)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }
            return r;

     }
        else
        {

            //Vorw�rts3
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX, CurrentY - 3] = true;
                }
            }

            //2 links 1 runter 
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 2] = true;
                }
            }

            //2 links 1 hoch
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 2] = true;
                }
            }

            //1 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 1] = true;
                }
            }

            //1 links 2 runter
            if (CurrentX != 6 && CurrentX != 7 && CurrentY != 0 && CurrentY != 1)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 1] = true;
                }
            }

            //3 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY] = true;
                }
            }

            //3 runter
            if (CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY];
                c2 = Game.Instance.Playerx[CurrentX + 2, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 3, CurrentY] = true;
                }
            }

            //1 rechts 2 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 1] = true;
                }
            }

            //1 rechts 2 runter
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 1] = true;
                }
            }

            //2 rechts 1 hoch
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 0)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //2 rechts 1 runter
            if (CurrentY != 14 && CurrentY != 15 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 2];
                c2 = Game.Instance.Playerx[CurrentX + 1, CurrentY];
                c3 = Game.Instance.Playerx[CurrentX + 1, CurrentY + 1];
                if (c == null && c2 == null && c3 == null)
                {
                    r[CurrentX + 1, CurrentY + 2] = true;
                }
            }

            //3 rechts
            if (CurrentY != 13 && CurrentY != 14 && CurrentY != 15)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 3] = true;
                }
            }

            return r;
        }



    }
    
}
