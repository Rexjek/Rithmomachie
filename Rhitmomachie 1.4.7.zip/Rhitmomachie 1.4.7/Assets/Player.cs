using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Player : MonoBehaviour {

    public int CurrentX { set; get; }
    public int CurrentY { set; get; }
    public bool isWhite; 

    public void SetPosition(int x,int y)
    {
        CurrentX = x ;
        CurrentY = y ;

    }
    public virtual bool[,] PossibleMove()
    {
        return new bool[10,18];

    }

    void OnMouseOver()
    {
        //If your mouse hovers over the GameObject with the script attached, output this messag
        Game.Instance.selectedPlayer = this;
        Debug.Log("weeh");
       
    }

    void OnMouseExit()
    {
        //The mouse is no longer hovering over the GameObject so output this message each frame
        Game.Instance.selectedPlayer = null;
        Debug.Log("b�h");
    }
}
