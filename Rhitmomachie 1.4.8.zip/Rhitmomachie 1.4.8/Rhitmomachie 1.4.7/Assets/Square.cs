using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Square : Player
{
    public override bool[,] PossibleMove()
    {

        bool[,] r = new bool[10, 18];
        Player c, c2, c3, c4;

        c = null;
        c2 = null;
        c3 = null;
        c4 = null;
        Debug.Log(CurrentX + " " + CurrentY);



        if (!isWhite)
        {
            
            //4 links
            if (CurrentY != 0  && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = c2 = c3 = c4 = null;

                c  = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 3 ? Game.Instance.Playerx[CurrentX, CurrentY - 4] : Game.Instance.Playerx[CurrentX, CurrentY];
                
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }               
            }

            //4 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 12 ? Game.Instance.Playerx[CurrentX, CurrentY + 4] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }

            //4 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = c2 = c3 = c4 = null;

				c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 3 ? Game.Instance.Playerx[CurrentX - 4, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            //4 runter 
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentX != 4)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 4 ? Game.Instance.Playerx[CurrentX + 4, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }
			
            //2 hoch 2 rechts
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 14 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            //2 rechts 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 15 && CurrentY != 14)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            //2 hoch 2 links
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //2 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //2 rechts 2 runter 
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7 )
            {
                c = c2 = c3 = c4 = null;
				
				c  = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            //2 links 2 runter
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY > 0 ? Game.Instance.Playerx[CurrentX , CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX , CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            //1 runter 3 links
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c  = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX +1, CurrentY - 3] = true;
                }
            }

            //3 links 1 runter 
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY < 13 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //3 rechts 1 runter 
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 13 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 0 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX -1, CurrentY - 3] = true;
                }
            }

            //3 links 1 hoch 
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c  = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 2 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 0 && CurrentY < 13 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //3 rechts 1 hoch 
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentX != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 13 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //3 runter 1 links
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY -1] = true;
                }
            }

            //1 links 3 runter 
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 0 && CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //1 rechts 3 runter
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //3 hoch 1 links 
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY -1] = true;
                }
            }

            //1 links 3 hoch 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY > 0? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 0 && CurrentY > 0? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY > 0? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }

            //3 hoch 1 rechts 
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2  && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            //1 rechts 3 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = c2 = c3 = c4 = null;

				c  = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
				
                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            return r;
        }
        else
        {

            //4 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 3 ? Game.Instance.Playerx[CurrentX, CurrentY - 4] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }
            }

            //4 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 12 ? Game.Instance.Playerx[CurrentX, CurrentY + 4] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }

            //4 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 3 ? Game.Instance.Playerx[CurrentX - 4, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            //4 runter 
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentX != 4)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 4 ? Game.Instance.Playerx[CurrentX + 4, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }

            //2 hoch 2 rechts
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 14 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            //2 rechts 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 15 && CurrentY != 14)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            //2 hoch 2 links
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //2 links 2 hoch
            if (CurrentX != 0 && CurrentX != 1 && CurrentY != 0 && CurrentY != 1)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 1 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //2 runter 2 rechts
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //2 rechts 2 runter 
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //2 runter 2 links
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            //2 links 2 runter
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 6 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            //1 runter 3 links
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            //3 links 1 runter 
            if (CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            //1 runter 3 rechts
            if (CurrentX != 7 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 7 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 7 && CurrentY < 13 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //3 rechts 1 runter 
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentX != 7)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 13 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //1 hoch 3 links
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY > 1 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 0 && CurrentY > 2 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //3 links 1 hoch 
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 1 ? Game.Instance.Playerx[CurrentX, CurrentY - 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 2 ? Game.Instance.Playerx[CurrentX, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 2 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //1 hoch 3 rechts
            if (CurrentX != 0 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 0 && CurrentY < 14 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 0 && CurrentY < 13 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //3 rechts 1 hoch 
            if (CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentX != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY < 14 ? Game.Instance.Playerx[CurrentX, CurrentY + 2] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY < 13 ? Game.Instance.Playerx[CurrentX, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY < 13 && CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 3] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //3 runter 1 links
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX + 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //1 links 3 runter 
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentY > 0 && CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentY > 0 && CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentY > 0 && CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //3 runter 1 rechts
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX < 7 ? Game.Instance.Playerx[CurrentX + 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 6 ? Game.Instance.Playerx[CurrentX + 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 5 ? Game.Instance.Playerx[CurrentX + 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //1 rechts 3 runter
            if (CurrentX != 7 && CurrentX != 6 && CurrentX != 5 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX < 7 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX < 6 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX < 5 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX + 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            //3 hoch 1 links 
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentY != 0)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }

            //1 links 3 hoch 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY > 0 ? Game.Instance.Playerx[CurrentX, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 2, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY > 0 ? Game.Instance.Playerx[CurrentX - 3, CurrentY - 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }

            //3 hoch 1 rechts 
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentY != 15)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentX > 0 ? Game.Instance.Playerx[CurrentX - 1, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 1 ? Game.Instance.Playerx[CurrentX - 2, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 2 ? Game.Instance.Playerx[CurrentX - 3, CurrentY] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];


                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            //1 rechts 3 hoch
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = c2 = c3 = c4 = null;

                c = CurrentY < 15 ? Game.Instance.Playerx[CurrentX, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c2 = CurrentX > 0 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 1, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c3 = CurrentX > 1 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 2, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];
                c4 = CurrentX > 2 && CurrentY < 15 ? Game.Instance.Playerx[CurrentX - 3, CurrentY + 1] : Game.Instance.Playerx[CurrentX, CurrentY];

                if (c == null && c2 == null && c3 == null && c4 == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }


            return r;
        }




    }
}