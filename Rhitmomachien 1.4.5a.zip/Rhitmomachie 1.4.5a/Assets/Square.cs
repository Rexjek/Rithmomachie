using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Square : Player
{
    public override bool[,] PossibleMove()
    {

        bool[,] r = new bool[10, 18];
        Player c, c2;

        c = null;
        c2 = null;



        if (!isWhite)
        {
            
            //Vorw�rts4
            if (CurrentY != 0  && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 4];
                if (c == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }               
            }

            //:D
            if (CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3 )
            {
                
                c = Game.Instance.Playerx[CurrentX +1, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX +1, CurrentY - 3] = true;
                }
            }

            //:D
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 )
            {
                c = Game.Instance.Playerx[CurrentX -1, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX -1, CurrentY - 3] = true;
                }
            }

            //:D
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 )
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //:D
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 )
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

          


            //R�ckw�rts4
            if (CurrentY != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12 )
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 4];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }

            

            //Rechts 4
            if (CurrentX != 6 && CurrentX != 7 && CurrentX != 5 && CurrentX != 4)
            {
                c = Game.Instance.Playerx[CurrentX + 4, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }

            //Rechts 
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5 )
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY -1] = true;
                }
            }

            //Rechts 
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5 )
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            // Links 4
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 4, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            // Links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY -1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY -1] = true;
                }
            }


            // Links 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // Links 2
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 )
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // Links 2
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 )
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //Rechts 2
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7 )
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //Rechts 2
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7 )
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            return r;
        }
        else
        {
         

            //Vorw�rts4
            if ( CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13 && CurrentY != 12 )
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY + 4];
                if (c == null)
                {
                    r[CurrentX, CurrentY + 4] = true;
                }
            }

         
            //R�ckw�rts4
            if (CurrentY != 0 && CurrentY != 16 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3 && CurrentY != 4)
            {
                c = Game.Instance.Playerx[CurrentX, CurrentY - 4];
                if (c == null)
                {
                    r[CurrentX, CurrentY - 4] = true;
                }
            }


           
            //Rechts 4
            if (CurrentX != 6 && CurrentX != 7 && CurrentX != 5 && CurrentX != 4)
            {
                c = Game.Instance.Playerx[CurrentX + 4, CurrentY];
                if (c == null)
                {
                    r[CurrentX + 4, CurrentY] = true;
                }
            }

           

            // Links 4
            if (CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 4, CurrentY];
                if (c == null)
                {
                    r[CurrentX - 4, CurrentY] = true;
                }
            }

            //:D
            if (CurrentX != 7 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY - 3] = true;
                }
            }

            //:D
            if (CurrentX != 0 && CurrentY != 0 && CurrentY != 1 && CurrentY != 2 && CurrentY != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY - 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY - 3] = true;
                }
            }

            //:D
            if (CurrentX != 7 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {

                c = Game.Instance.Playerx[CurrentX + 1, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX + 1, CurrentY + 3] = true;
                }
            }

            //:D
            if (CurrentX != 0 && CurrentY != 16 && CurrentY != 15 && CurrentY != 14 && CurrentY != 13)
            {
                c = Game.Instance.Playerx[CurrentX - 1, CurrentY + 3];
                if (c == null)
                {
                    r[CurrentX - 1, CurrentY + 3] = true;
                }
            }

            //Rechts 
            if (CurrentY != 0 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY - 1] = true;
                }
            }

            //Rechts 
            if (CurrentY != 15 && CurrentX != 6 && CurrentX != 7 && CurrentX != 5)
            {
                c = Game.Instance.Playerx[CurrentX + 3, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX + 3, CurrentY + 1] = true;
                }
            }

            // Links 
            if (CurrentY != 0 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY - 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY - 1] = true;
                }
            }


            // Links 
            if (CurrentY != 15 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2 && CurrentX != 3)
            {
                c = Game.Instance.Playerx[CurrentX - 3, CurrentY + 1];
                if (c == null)
                {
                    r[CurrentX - 3, CurrentY + 1] = true;
                }
            }

            // Links 2
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY + 2] = true;
                }
            }

            // Links 2
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 0 && CurrentX != 1 && CurrentX != 2)
            {
                c = Game.Instance.Playerx[CurrentX - 2, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX - 2, CurrentY - 2] = true;
                }
            }

            //Rechts 2
            if (CurrentY != 15 && CurrentY != 14 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY + 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY + 2] = true;
                }
            }

            //Rechts 2
            if (CurrentY != 0 && CurrentY != 1 && CurrentX != 6 && CurrentX != 7)
            {
                c = Game.Instance.Playerx[CurrentX + 2, CurrentY - 2];
                if (c == null)
                {
                    r[CurrentX + 2, CurrentY - 2] = true;
                }
            }

            return r;
        }




    }
}