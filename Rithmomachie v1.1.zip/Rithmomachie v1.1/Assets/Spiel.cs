﻿
using UnityEngine;
using System.Collections.Generic; 
public class Spiel : MonoBehaviour {

    //Deaktivierung der Spielsteine durch X-/Y-Wert = -1
    private int selectionX = -1;
    private int selectionY = -1;

    public List<GameObject> spielsteine_1;
    private List<GameObject> aktivespielsteine;
    private void Start()
    {


    }
    // Update is called once per frame
     public void Update() {

        UpdateSelection();
        Brett();
    }


    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("SpielBrett")))
        {
            
            selectionX = (int)hit.point.x;
            selectionY = (int)hit.point.z;
        }
        else
        {
            selectionX = -1;
            selectionY = -1;
        }
    }

    public void  Brett()
    {
        Vector3 breiteLinie = Vector3.right * 8;
        Vector3 laengeLinie = Vector3.forward * 16;
        for (int i = 0; i <= 16; i++)
        {
            Vector3 start = Vector3.forward * i ; 
            Debug.DrawLine(start,start +breiteLinie );
            for (int k = 0; k <= 8; k++)
            {
                 start = Vector3.right  * k;
                Debug.DrawLine(start, start + laengeLinie);
            }
        }
        

      // selection
      if(selectionX >= 0 && selectionY >= 0)
        {
            Debug.DrawLine(
                Vector3.forward * selectionY + Vector3.right * selectionX,
                Vector3.forward * (selectionY + 1) + Vector3.right * (selectionX + 1));

            Debug.DrawLine(
                 Vector3.forward *( selectionY + 1) + Vector3.right * selectionX,
                 Vector3.forward * selectionY  + Vector3.right * (selectionX + 1));

        }
    }
}

