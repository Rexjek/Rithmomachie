using UnityEngine;
using System.Collections.Generic;

public class Game : MonoBehaviour {
    //Spieler == Spielstein
    public Player[,] Player2 { set; get; }
    private Player selectedPlayer;

    //Deaktivierung der Spielsteine durch X-/Y-Wert = -1
    private const float tileSize = 1.0f;
    private const float tileDiameter = 0.5f;

    private int selectionX = -1;
    private int selectionY = -1;

    public List<GameObject> tokens1;
    private List<GameObject> activeTokens;

    private Quaternion orientation = Quaternion.Euler(0, 180, 0);

    public bool isWhiteTurn = true;

    private void Start()
    {
        SpawnAll();

    } //Spawner

    private void SpawnAll()
    {
        activeTokens = new List<GameObject>();
        Player2 = new Player[8, 16];

        //Weisses team

        //Weiss, Kreis 1

        SpawnToken(0, 2, 3);

        SpawnToken(1, 3, 3);

        SpawnToken(2, 4, 3);

        SpawnToken(3, 5, 3);

        //Weiss, Kreis 2  

        SpawnToken(4, 2, 2);

        SpawnToken(5, 3, 2);

        SpawnToken(6, 4, 2);

        SpawnToken(7, 5, 2);

        //Weiss, Viereck 1

        SpawnToken(8, 0, 1);

        SpawnToken(9, 1, 1);

        SpawnToken(10, 6, 1);

        SpawnToken(11, 7, 1);

        //Weiss, Viereck 2

        SpawnToken(12, 0, 0);

        SpawnToken(13, 1, 0);

        SpawnToken(14, 6, 0);

        SpawnToken(15, 7, 0);

        //Weiss, Dreieck 1

        SpawnToken(16, 0, 2);

        SpawnToken(17, 1, 2);

        SpawnToken(18, 6, 2);

        SpawnToken(19, 7, 2);

        //Weiss, Dreieck 2

        SpawnToken(16, 2, 1);

        SpawnToken(17, 3, 1);

        SpawnToken(18, 4, 1);

        SpawnToken(19, 5, 1);

        //Schwarz, Kreis 1

        SpawnToken(20, 2, 12);

        SpawnToken(21, 3, 12);

        SpawnToken(23, 4, 12);

        SpawnToken(24, 5, 12);

        //Schwarz, Kreis 2


        SpawnToken(25, 2, 13);

        SpawnToken(26, 3, 13);

        SpawnToken(27, 4, 13);

        SpawnToken(28, 5, 13);

        //Schwarz, Viereck 1

        SpawnToken(29, 0, 15);

        SpawnToken(30, 1, 15);

        SpawnToken(31, 6, 15);

        SpawnToken(32, 7, 15);

        //Schwarz, Viereck 2

        SpawnToken(33, 0, 14);

        SpawnToken(34, 1, 14);

        SpawnToken(35, 6, 14);

        SpawnToken(36, 7, 14);

        //Schwarz, Kugel 1

        SpawnToken(37, 2, 14);

        SpawnToken(38, 3, 14);

        SpawnToken(39, 4, 14);

        SpawnToken(40, 5, 14);

        //Schwarz, Kugel 2

        SpawnToken(41, 0, 13);

        SpawnToken(42, 1, 13);

        SpawnToken(43, 6, 13);

        SpawnToken(44, 7, 13);


    }// steine methode (x/z position) 

    private Vector3 Middle(int x, int z)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (tileSize * x) + tileDiameter;
        origin.z += (tileSize * z) + tileDiameter;
        return origin;
    } // spawn punkt fuktion
    
    // Update  wird einmal pro frame aufgerufen
    public void Update() {

        UpdateSelection();
        Board();

        if (Input.GetMouseButtonDown(0)) // Auswählen (0= linke maustaste)
        {
            if (selectionX >= 0 && selectionY >= 0)
            {
                if (selectedPlayer == null)
                {
                    //Wähle Spieler aus
                    SelectPlayer(selectionX,selectionY);
                }
                else
                {
                    //Bewege den Spieler
                    movePlayer(selectionX, selectionY);
                }

            }
        }
    }

    private void SelectPlayer (int x, int y)
     {
        if (Player2[x, y] == null)
            return;

        if (Player2[x, y].isWhite != isWhiteTurn)
            return;

        selectedPlayer = Player2[x, y];

        
     }

    private void movePlayer(int x,int y)
    {
        if (selectedPlayer.PossibleMove(x, y))
        {
            Player2[selectedPlayer.CurrentX, selectedPlayer.CurrentY] = null;
            selectedPlayer.transform.position = Middle(x, y);
            Player2[x, y] = selectedPlayer;
            isWhiteTurn = !isWhiteTurn;
        }

        selectedPlayer = null;
    }
    
    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("Playboard")))
        {
            
            selectionX = (int)hit.point.x;
            selectionY = (int)hit.point.z;
        }
        else
        {
            selectionX = -1;
            selectionY = -1;
        }
    }

    public void Board()
    {
        Vector3 lineWidth = Vector3.right * 8;
        Vector3 lineLength = Vector3.forward * 16;
        for (int i = 0; i <= 16; i++)
        {
            Vector3 start = Vector3.forward * i ; 
            Debug.DrawLine(start, start + lineWidth );
            for (int k = 0; k <= 8; k++)
            {
                start = Vector3.right  * k;
                Debug.DrawLine(start, start + lineLength);
            }
        }
        

      //Selection
      if(selectionX >= 0 && selectionY >= 0)
        {
            Debug.DrawLine(
                Vector3.forward * selectionY + Vector3.right * selectionX,
                Vector3.forward * (selectionY + 1) + Vector3.right * (selectionX + 1));

            Debug.DrawLine(
                 Vector3.forward *( selectionY + 1) + Vector3.right * selectionX,
                 Vector3.forward * selectionY  + Vector3.right * (selectionX + 1));

        }
    }
    //Spawnt Steine
    public void SpawnToken(int index,int x, int y)
    {
        GameObject go = Instantiate(tokens1[index], Middle(x,y) , orientation) as GameObject; //Macht Steine mit dem Index 
        go.transform.SetParent(transform);
        Player2 [x, y] = go.GetComponent<Player>() ;
        Player2[x, y].SetPosition(x, y); 
        activeTokens.Add(go);
    }
}

